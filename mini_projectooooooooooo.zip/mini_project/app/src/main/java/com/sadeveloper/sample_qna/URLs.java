package com.sadeveloper.sample_qna;

class URLs {
    public static final String URL_LOGIN = "https://genderopinion.000webhostapp.com/login/login.php";
    public static final String URL_REGISTER= "https://genderopinion.000webhostapp.com/login/register.php";
    public static final String URL_GETUSERINFORMATIONS= "https://genderopinion.000webhostapp.com/login/getuser.php";
}
